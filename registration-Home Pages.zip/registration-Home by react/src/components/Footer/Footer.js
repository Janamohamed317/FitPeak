import React from 'react'
import footer from './Footer.module.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faInstagram } from '@fortawesome/free-brands-svg-icons';
import { faEnvelope, faPhone, faLocationPin } from "@fortawesome/free-solid-svg-icons";

function Footer() {
  return (
    <footer className={footer.main_container}>
      <div className={`row gx-0 ${footer.row}`}>
        <div className='col-sm-12 col-md-3 col-lg-3 d-flex justify-content-center p-3 '>
          <div className={footer.logo_icons_container}>
            <div className={footer.logo_icons_txt}>
              <h2>FitPeak</h2>
              <p>At FitPeak, we empower you to track, improve, and conquer your fitness journey</p>
              <hr className={footer.line} />
            </div>
            <div className={footer.icons_container}>
              <h3>Social Media</h3>
              <div className={footer.icons}>
                <FontAwesomeIcon icon={faFacebookF} className={footer.icon} />
                <FontAwesomeIcon icon={faTwitter} className={footer.icon} />
                <FontAwesomeIcon icon={faInstagram} className={footer.icon} />
              </div>
            </div>
          </div>
        </div>

        <div className='col-sm-12 col-md-3 col-lg-3 d-flex justify-content-center'>
          <div className={footer.info}>
            <h3 className='mb-4'>Quick Links</h3>
            <p>Home</p>
            <p>About</p>
            <p>Tips</p>
          </div>
        </div>

        <div className='col-sm-12 col-md-3 col-lg-3 d-flex justify-content-center p-2'>
          <div className={footer.contact_info}>
            <h3>Contact Us</h3>
            <p><FontAwesomeIcon icon={faEnvelope} className={footer.contact_icon} />
              support@fitnessapp.com</p>
            <p> <FontAwesomeIcon icon={faPhone} className={footer.contact_icon} />Phone: +1 234 567 890</p>
            <p> <FontAwesomeIcon icon={faLocationPin} className={footer.contact_icon} />Location: 123 Fit Street, Wellness City</p>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer