import React, { useContext, useState } from 'react';
import styles1 from './Signup.module.css';
import { AppContext } from '../Context/AppContext';
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';
import axios from 'axios';

function Signup() {
    const [email, setEmail] = useState('');
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [confirmedPassword, setConfirmedPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [userNameError, setUserNameError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [confirmedPasswordError, setConfirmedPasswordError] = useState('');
    const { setShowPassword, showPassword, handleCheckboxChange } = useContext(AppContext);
    const navigate = useNavigate();

    const validateField = (field, value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (field === 'email') {
            if (!value) {
                setEmailError('Email is required');
            } else if (!emailRegex.test(value)) {
                setEmailError('Invalid email format');
            } else {
                setEmailError('');
            }
        } else if (field === 'userName') {
            if (!value) {
                setUserNameError('Username is required');
            } else if (value.length < 3) {
                setUserNameError('Username must be at least 3 characters');
            } else {
                setUserNameError('');
            }
        } else if (field === 'password') {
            if (!value) {
                setPasswordError('Password is required');
            } else if (value.length < 6) {
                setPasswordError('Password must be at least 6 characters');
            } else {
                setPasswordError('');
            }
        } else if (field === 'confirmedPassword') {
            if (!value) {
                setConfirmedPasswordError('Please confirm your password');
            } else if (value !== password) {
                setConfirmedPasswordError("Passwords don't match");
            } else {
                setConfirmedPasswordError('');
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        validateField('email', email);
        validateField('userName', userName);
        validateField('password', password);
        validateField('confirmedPassword', confirmedPassword);

        if (emailError || userNameError || passwordError || confirmedPasswordError) {
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                text: 'Please fix the errors in the form before submitting.',
                confirmButtonText: 'OK',
            });
            return;
        }

        try {
            const res = await axios.post('https://your-api-endpoint.com/signup', {
                email,
                userName,
                password,
            });

            if (res.status === 200 || res.status === 201) {
                Swal.fire({
                    icon: 'success',
                    title: 'Signup Successful!',
                    text: 'You have successfully signed up.',
                    confirmButtonText: 'OK',
                }).then(() => {
                    setShowPassword(false);
                    navigate("/Signin");
                });
            } else if (res.status === 409) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Signup Failed',
                    text: 'Username or email is already taken. Please try another one.',
                    confirmButtonText: 'OK',
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Signup Failed',
                    text: 'Something went wrong. Please try again.',
                    confirmButtonText: 'OK',
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.response?.data?.message || 'There was an error signing up. Please try again.',
                confirmButtonText: 'OK',
            });
        }
    };

    return (
        <div className={styles1.main_container}>
            <div className={styles1.form_container}>
                <p className={styles1.moto}>Join us today and take the first step toward a healthier, stronger you!</p>
                <div className={styles1.form}>
                    <p className={styles1.Sigunp_text1}>Sign Up</p>
                    <form className={styles1.form_inputs} onSubmit={handleSubmit}>
                        <label className={`${styles1.Input_label}`}>Username</label>
                        <input className={styles1.input}
                            type='text'
                            placeholder="Username"
                            value={userName}
                            onChange={(e) => { setUserName(e.target.value); validateField('userName', e.target.value); }}
                        />
                        {userNameError && <p className={styles1.error_text}>{userNameError}</p>}

                        <label className={`${styles1.Input_label}`}>Email</label>
                        <input className={styles1.input}
                            placeholder="Email"
                            value={email}
                            onChange={(e) => { setEmail(e.target.value); validateField('email', e.target.value); }}
                        />
                        {emailError && <p className={styles1.error_text}>{emailError}</p>}

                        <label className={`${styles1.Input_label}`}>Password</label>
                        <input
                            className={styles1.input}
                            type={showPassword ? "text" : "password"}
                            placeholder="Password"
                            value={password}
                            onChange={(e) => { setPassword(e.target.value); validateField('password', e.target.value); }}
                        />
                        {passwordError && <p className={styles1.error_text}>{passwordError}</p>}

                        <label className={styles1.Input_label}>Confirm Password</label>
                        <input
                            className={styles1.input}
                            type={showPassword ? "text" : "password"}
                            placeholder="Confirm Password"
                            value={confirmedPassword}
                            onChange={(e) => { setConfirmedPassword(e.target.value); validateField('confirmedPassword', e.target.value); }}
                        />
                        {confirmedPasswordError && <p className={styles1.error_text}>{confirmedPasswordError}</p>}

                        <div className={styles1.form_checkbox_container}>
                            <label className={styles1.checkbox_label}>Show Password</label>
                            <input type='checkbox' className={styles1.form_checkbox} onChange={(e) => handleCheckboxChange(e)}></input>
                        </div>

                        <button className={styles1.form_btn} type="submit">
                            <span>Sign Up</span>
                        </button>
                    </form>
                    <p className={styles1.Sigunp_text2}>
                        Already have an account?<span className={styles1.Signup_text} onClick={() => navigate("/Signin")}> Sign in</span>
                    </p>
                </div>
            </div>
        </div>
    );
}

export default Signup;