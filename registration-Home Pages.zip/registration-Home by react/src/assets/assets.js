import hero from './hero.webp';
import hero1 from './hero1.png';
import hero2 from './hero2.jpg';
import gym from './gym.jpg'

export const imgs = {
    hero,
    hero1,
    hero2,
    gym,

};

export const reviews = [
    {
        id: 1,
        name: "Alex Churco",
        review: `A well-designed platform with an intuitive interface and seamless syncing with fitness devices. The analytics
        and goal-setting features are fantastic for tracking progress. Highly recommended for anyone serious about fitness!`,
        stars: 5
    },

    {
        id: 2,
        name: "Zack Swift",
        review: `The website offers great tracking tools for steps, calories, and heart rate, but I experienced occasional syncing delays.
        Customer support is responsive, and overall, it's a solid option for fitness tracking.`,
        stars: 4
    },
    {
        id: 3,
        name: "Zack Swift",
        review: `It does a good job with basic fitness tracking, but lacks customization for advanced users. More personalized insights and 
        workout templates would make it better. Still useful for general fitness tracking.`,
        stars: 3
    },
    {
        id: 4,
        name: "Zack Swift",
        review: `What stands out is the excellent customer support. The site is packed with useful features, from workout tracking to progress analysis. 
        A great choice for fitness enthusiasts looking for a comprehensive tool!`,
        stars: 4
    },
    {
        id: 5,
        name: "Zack Swift",
        review: `This website makes tracking fitness so easy, especially for beginners. The guided workouts and step-by-step progress 
        tracking keep me motivated.Syncs well with my smartwatch, and the dashboard is easy to understand.`,
        stars: 4
    },


];

